#pragma once
#ifndef INTERACTIVE_H
#define INTERACTIVE_H

#include <string>
#include <vector>
#include <iostream>
#include <string>
#include <algorithm>
#include <ctime>

using namespace std;

// List of the 10 (out of 14) features that I applied in the project.
// 1. Opening screen with a description of the application and instructions.
// 2. Menu for the user to choose options.
// 3. 4 classes.
// 4. Inheritance (minimum 2 derived classes).
// 5. Dynamic Polymorphism.
// 6. Encapsulation.
// 7. File input and output processing OR network communication (e.g. remote data storage)
// 8. Vectors.
// 9. Iterators.
// 10. Boost Library (or any library other than the STL).

class Interactive
{
public:
	Interactive();
	// All the function prototypes.
	void WelcomeUserToGame();
	void ScreenFormat();
	void SubScreenFormat();
	void UserHelp();
	void StoryIntroduction();
	void HackerInfiltration();
	void StoryInteractionGameInstructions();
	void StoryInteractionGame();
	void CongratulateUserForDecryptingWord();
	void GetTextFromUser();
	void WonderingUser();
	void display(const std::vector<std::string>* const pInventory);
	void hackedTransaction(int& x, int& y);
	~Interactive();
};


class Card
{
public:
	// The card values under enumeration.
	enum CardValue
	{
		ACE = 1, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN,
		JACK, QUEEN, KING
	};

	// The card suits under enumeration.
	enum Suit
	{
		CLUBS, DIAMONDS, HEARTS, SPADES
	};

	// Overloading operator so it can send Card object to the standard output. 
	friend ostream& operator<<(ostream& os, const Card& xCard);

	Card(CardValue  CV = ACE, Suit S = SPADES, bool ifu = true);

	// Returns the value of the card.
	int GetValue() const;

	// "Flips" the card and shows whether the card is facing up or down.
	void Flip();
private:
	CardValue X_CardValue;
	Suit X_Suit;
	bool X_IsFaceUp;
};

class Hand
{
public:
	Hand();

	virtual ~Hand();

	// Adds a card to the hand.
	void Add(Card* pCard);

	// Clears hand of all cards.
	void Clear();

	// Get the total value of the cards in hand.
	int ValueTotal() const;
protected:
	vector<Card*> X_Cards;
};

class OtherPlayer : public Hand
{
	friend ostream& operator<<(ostream& os, const OtherPlayer& xOtherPlayer);
public:
	OtherPlayer(const string& name = "");

	virtual ~OtherPlayer();

	// Determine if the other player wants to continue hitting.
	virtual bool IsHitting() const = 0;

	// Boolean value to tell if the other player has a value higher than 21 in their hand.
	bool IsBusted() const;

	// Informs the user of the program that the other player have busted.
	void Bust() const;
protected:
	string X_Name;
};

class Player : public OtherPlayer
{
public:
	Player(const string& name = "");

	virtual ~Player();

	// Determine if the player (user) wants to continue hitting.     
	virtual bool IsHitting() const;

	// Informs the user of the program that they have won.
	void Win() const;

	// Informs the user of the program that they have lost.
	void Lose() const;

	// Informs the user of the program that they have had a push (essentially a tie).
	void Push() const;
};

class House : public OtherPlayer
{
public:
	House(const string& name = "House");

	virtual ~House();

	// Determine if the house (employee who invited user) wants to continue hitting. 
	virtual bool IsHitting() const;

	// The house will flip over the first card.
	void FlipFirstCard();
};

class Deck : public Hand
{
public:
	Deck();

	virtual ~Deck();

	// Establish that there will be 52 cards in the deck.
	void AmountOfCards();

	// Commits the action of shuffling cards.
	void Shuffle();

	// Commits the action of dealing a card to the hand.
	void Deal(Hand& aHand);

	// Commits the action of giving other player(s) additional cards.
	void AdditionalCards(OtherPlayer& xOtherPlayer);
};

class BlackJack
{
public:
	BlackJack(const vector<string>& names);

	~BlackJack();

	// The function prototype that will initiate the game of Blackjack.
	void Play();

private:
	Deck X_Deck;
	House X_House;
	vector<Player> X_Players;
};

#endif  
