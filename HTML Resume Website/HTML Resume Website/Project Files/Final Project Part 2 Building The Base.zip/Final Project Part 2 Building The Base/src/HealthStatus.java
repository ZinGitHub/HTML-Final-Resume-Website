public class HealthStatus extends CrewTool
{
    // Declared variable.
    public String CrewCondition;

    // Constructor for HealthStatus.
    public HealthStatus(String CrewCondition)
    {
        // Recall the parent constructor with the addition of CrewCondition.
        super(CrewCondition);
    }
}
